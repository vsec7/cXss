    <!-- Footer -->
    <footer class="footer">
      <div class="container">
              <center>
                <a href="https://github.com/vsec7" class="btn btn-block btn-outline-<?=$warna;?>">
                  <span class="fa fa-github"> Versailles <span class="fa-heart"></span> Cans21 </span>
                </a>
              </center>
      </div>
    </footer>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="../assets/js/jquery-3.3.1.slim.min.js"></script>
    <script src="../assets/js/popper.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>

  </body>

</html>