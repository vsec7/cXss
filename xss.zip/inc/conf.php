<?php
include("function.php");

// Configurations

// jsonstore.io
$db = ""; // https://www.jsonstore.io/f00be623cbc63371b87xxxxxxxxxxxxxxxxxxx

// Password For Login
$pass = "a820fa8139a40b4590608dd738348d0a"; // default md5 pass : cans , Empty this field if not used

// Set Your Telegram Bot Token & Telegram Recipient ID
$token = ""; // Empty this field if not used
$idRecipient = ""; // Empty this field if not used

// Set Your Email Address
$email = ""; // Empty this field if not used

// -----------------------------------------------------------------------------------------------
$warna = rand_color(); // you can set rand_color() OR which one "primary","success","danger","warning","secondary"
